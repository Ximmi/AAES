/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author raulr_000
 */
public class CambClien extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You ma.y use following sample code. */
            String submit = request.getParameter("submit");

            Connection c = null;
            Statement s = null;
            ResultSet r = null;

            secionzitas.Usuario sesion = new secionzitas.Usuario();
            HttpSession ses = request.getSession();

            try {
                BD.cDatos conec = new BD.cDatos();
                conec.conectar();
                sesion.getNombre();
                r = conec.consulta("select * from Usuario where nombre='" + ses.getAttribute("Nombre") + "'");
                out.print("<table border='1'>");

                if (r.next()) {
                    String tipo = r.getString("tipo");
                    String nombre = r.getString("nombre");
                    String edad = r.getString("edad");
                    String direccion = r.getString("direccion");
                    String correo = r.getString("correo");

                    out.println("<html>\n"
                            + "    <head>\n"
                            + "        <title>Registro</title>\n"
                            + "        <!--Import Google Icon Font-->\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Raleway\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Muli\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Shadows+Into+Light+Two\" rel=\"stylesheet\">\n"
                            + "        <!--Import materialize.css-->\n"
                            + "        <link type=\"text/css\" rel=\"stylesheet\" href=\"css/materialize.min.css\"  media=\"screen,projection\"/>\n"
                            + "        <meta charset=\"UTF-8\">\n"
                            + "        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    </head>\n"
                            + "    <body style=\"background-image: url(IMG/mini.jpg) \">\n"
                            + "        <!--Import jQuery before materialize.js-->\n"
                            + "        <script type=\"text/javascript\" src=\"https://code.jquery.com/jquery-2.1.1.min.js\"></script>\n"
                            + "        <script type=\"text/javascript\" src=\"js/materialize.min.js\"></script> \n"
                            + "        <form action=\"nidas/altas.jsp\" method=\"POST\" name=\"altas\">\n"
                            + "\n"
                            + "\n"
                            + "            <!--ÉSTA ES LA PARTE ROSA!!!-->\n"
                            + "            <nav>\n"
                            + "                <div class=\"nav-wrapper\" style=\"font-family: Raleway\">\n"
                            + "                    <!--a href=\"\" class=\"brand-logo\">Slogan de Armavi Fiore</a!-->\n"
                            + "                    <a href=\"\" class=\"brand-logo\" style=\"font-family: Shadows Into Light Two\">&nbsp;&nbsp; Cambios</a>\n"
                            + "                    <ul id=\"nav-mobile\" class=\"right hide-on-med-and-down\">\n"
                            + "                        <li><a class=\"dropdown-button\" href=\" \" data-activates=\"quienessomos\">¿Quiénes somos?<i class=\"material-icons right\">arrow_drop_down</i></a></li>\n"
                            + "                        <li><a href=\"contacto.html\">Contacto</a></li>\n"
                            + "                        <li><a href=\"index.html\">Página Principal</a></li>\n"
                            + "                    </ul>\n"
                            + "\n"
                            + "                    <ul id=\"quienessomos\" class=\"dropdown-content\">\n"
                            + "                        <li><a href=\"sobreempresa.html\">Sobre la empresa</a></li>\n"
                            + "                        <li><a href=\"ubicacion.html\">Ubicación</a></li>\n"
                            + "                        <li><a href=\"nproductos.html\">Nuestros productos</a></li>\n"
                            + "                    </ul>\n"
                            + "                </div>\n"
                            + "            </nav>\n"
                            + "\n"
                            + "            <div class=\"row\">\n"
                            + "                <div class=\"col s3\"> </div>\n"
                            + "\n"
                            + "                <!-- Contenedor :3 -->\n"
                            + "                <div class=\"col s6\">\n"
                            + "                    <div class=\"container\" style=\"font-family: Raleway; font-size: 20px; \">\n"
                            + "                        <br><br>\n"
                            + "                        <!--h3 style=\"color: #050f14; font-family: Muli\">Regístrate!</h3-->\n"
                            + "\n"
                            + "                        <div class=\"card-panel\">\n"
                            + "                            <table>\n"
                            + "        <thead>\n"
                            + "          <tr>\n"
                            + "              <th data-field=\"id\">Tipo</th>\n"
                            + "              <th data-field=\"name\">Nombre</th>\n"
                            + "              <th data-field=\"price\">Edad</th>\n"
                            + "              <th data-field=\"direccion\">Direccion</th>\n"
                            + "              <th data-field=\"correo\">correo</th>\n"
                            + "          </tr>\n"
                            + "        </thead>\n"
                            + "\n"
                            + "        <tbody>\n"
                            + "          <tr>\n"
                            + "<td>" + tipo + "</td>"
                            + "<td>" + nombre + "</td>"
                            + "<td>" + edad + "</td>"
                            + "<td>" + direccion + "</td>"
                            + "<td>" + correo + "</td>"
                            + "          </tr>\n"
                            + "          <tr>\n"
                            + "        </tbody>\n"
                            + "      </table>\n"
                            + "\n"
                            + "                        </div> <!--del contenedor-->\n"
                            + "                    </div>\n"
                            + "                </div>\n"
                            + "                <div class=\"col s3\"> </div>\n"
                            + "\n"
                            + "            </div>\n"
                            + "        </form>\n"
                            + "<div class=\"card-panel\">\n"
                            + "<form action=\"CambiosC\" method=\"POST\">"
                            + "                            &nbsp;&nbsp;Dirección:\n"
                            + "                            <input type=\"text\" name=\"direccion\" id=\"direccion\" required class=\"validate\"/>\n"
                            + "                            <br>\n"
                            + "                            <!--input type=\"submit\" name=\"alta\" value=\"Alta\"-->\n"
                            + "                            <button class=\"btn waves-effect waves-light\" type=\"submit\" name=\"altas\">Cmbiar\n"
                            + "                                <i class=\"material-icons right\">send</i>\n"
                            + "                            </button>\n"
                            + "\n"
                            + "                        </div> <!--del contenedor-->"
                            + "</form>"
                            + "    </body>\n"
                            + "</html>\n");
                }

            } catch (SQLException ex) {
                ex.toString();

            }
        }
    }

}
