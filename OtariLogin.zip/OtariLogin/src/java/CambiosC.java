/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author raulr_000
 */
public class CambiosC extends HttpServlet {

   protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
      secionzitas.Usuario sesion = new secionzitas.Usuario();
            HttpSession ses = request.getSession();
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String nombre = request.getParameter("nombre");
            String tipo = request.getParameter("tipo");
            int edad = Integer.parseInt(request.getParameter("edad"));
            String direccion = request.getParameter("direccion");
            String correo = request.getParameter("correo");

            try {
                BD.cDatos cambio = new BD.cDatos();
                cambio.conectar();
                cambio.actualizar("update Usuario set direccion='" + direccion +"' where nombre='" +ses.getAttribute("Nombre")  + "'");
                out.println("<script>alert('Cambios realizados correctamente');</script>");
                cambio.cierraConexion();
                response.sendRedirect("logout.jsp");

            } catch (SQLException error) {
                out.print(error.toString());
            }
        }
}}

