/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Alumno
 * modificado por: Ximmi (2/12/2016)
 */
public class Registrar extends HttpServlet {
     String correo;
    String nombre;
    String contra;
    String edad;
    String direccion;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String nombre = request.getParameter("nombre");
            String contra = request.getParameter("contra");
            String correo = request.getParameter("correo");
            String edad = request.getParameter("edad");
            String direccion = request.getParameter("direccion");
            
        out.println("<html>");
        out.println("<head><title>Respuesta al Formulario del Servlet</title></head>");
        out.println("<body>");
        out.println("<p><h1><center>Su nombre es:<B>" + nombre + "</B> </center></h1></p>");
        out.println("hoy es " + new Date());
        out.println("</body></html>");
        out.close();
        }
    }
}
