/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alumno
 */
public class Consulta extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String submit = request.getParameter("submit");
            String nom = request.getParameter("nombre");

            Connection c = null;
            Statement s = null;
            ResultSet r = null;

            if (submit.equals("Consultar todo")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Usuario");
                    out.print("<table border='1'>");
out.println("<html>\n"
                            + "    <head>\n"
                            + "        <title>Cambios</title>\n"
                            + "        <!--Import Google Icon Font-->\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Raleway\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Muli\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Shadows+Into+Light+Two\" rel=\"stylesheet\">\n"
                            + "        <!--Import materialize.css-->\n"
                            + "        <link type=\"text/css\" rel=\"stylesheet\" href=\"css/materialize.min.css\"  media=\"screen,projection\"/>\n"
                            + "        <meta charset=\"UTF-8\">\n"
                            + "        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    </head>\n"
                            + "    <body style=\"background-image: url(IMG/mini.jpg) \">\n"
                            + "        <!--Import jQuery before materialize.js-->\n"
                            + "        <script type=\"text/javascript\" src=\"https://code.jquery.com/jquery-2.1.1.min.js\"></script>\n"
                            + "        <script type=\"text/javascript\" src=\"js/materialize.min.js\"></script> \n"
                            + "        <form action=\"nidas/cambios.jsp\" method=\"POST\" name=\"altas\">\n"
                            + "\n"
                            + "\n"
                            + "            <!--ÉSTA ES LA PARTE ROSA!!!-->\n"
                            + "            <nav>\n"
                            + "                <div class=\"nav-wrapper\" style=\"font-family: Raleway\">\n"
                            + "                    <!--a href=\"\" class=\"brand-logo\">Slogan de Armavi Fiore</a!-->\n"
                            + "                    <a href=\"\" class=\"brand-logo\" style=\"font-family: Shadows Into Light Two\">&nbsp;&nbsp; Consultale Papu</a>\n"
                            + "                    <ul id=\"nav-mobile\" class=\"right hide-on-med-and-down\">\n"
                            + "                        <li><a class=\"dropdown-button\" href=\" \" data-activates=\"quienessomos\">¿Quiénes somos?<i class=\"material-icons right\">arrow_drop_down</i></a></li>\n"
                            + "                        <li><a href=\"contacto.html\">Contacto</a></li>\n"
                       
                            + "                    </ul>\n"
                            + "\n"
                            + "                    <ul id=\"quienessomos\" class=\"dropdown-content\">\n"
                            + "                        <li><a href=\"sobreempresa.html\">Sobre la empresa</a></li>\n"
                            + "                        <li><a href=\"ubicacion.html\">Ubicación</a></li>\n"
                            + "                        <li><a href=\"nproductos.html\">Nuestros productos</a></li>\n"
                            + "                    </ul>\n"
                            + "                </div>\n"
                            + "            </nav>\n"
                            + "\n"
                            + "            <div class=\"row\">\n"
                            + "                <div class=\"col s3\"> </div>\n"
                            + "\n"
                            + "                <!-- Contenedor :3 -->\n"
                            + "                <div class=\"col s6\">\n"
                            + "                    <div class=\"container\" style=\"font-family: Raleway; font-size: 20px; \">\n"
                            + "                        <br><br>\n"
                            + "                        <!--h3 style=\"color: #050f14; font-family: Muli\">Regístrate!</h3-->\n"
                            + "\n");

                    while (r.next()) {
                        String tipo = r.getString("tipo");
                        String nombre = r.getString("nombre");
                        String edad = r.getString("edad");
                        String direccion = r.getString("direccion");
                        String correo = r.getString("correo");
                 
                        out.println("<tr>"
                                + "<td>" + tipo + "</td>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + edad + "</td>"
                                + "<td>" + direccion + "</td>"
                                + "<td>" + correo + "</td>"
                                + "</tr>"
                                        );
        }
                           out.println( "                        </div> <!--del contenedor-->\n"
                            + "                    </div>\n"
                            + "                </div>\n"
                            + "                <div class=\"col s3\"> </div>\n"
                            + "\n"
                            + "            </div>\n"
                            + "        </form>\n"
                            + "    </body>\n"
                            + "</html>\n"
                            + "");
     
                    
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
            if (submit.equals("Consultar nombre")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Usuario where nombre='" + nom + "'");
                    out.print("<table border='1'>");

                    if (r.next()) {
                        String tipo = r.getString("tipo");
                        String nombre = r.getString("nombre");
                        String edad = r.getString("edad");
                        String direccion = r.getString("direccion");
                        String correo = r.getString("correo");

                        out.println("<html>\n"
                            + "    <head>\n"
                            + "        <title>Cambios</title>\n"
                            + "        <!--Import Google Icon Font-->\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Raleway\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Muli\" rel=\"stylesheet\">\n"
                            + "        <link href=\"http://fonts.googleapis.com/icon?family=Shadows+Into+Light+Two\" rel=\"stylesheet\">\n"
                            + "        <!--Import materialize.css-->\n"
                            + "        <link type=\"text/css\" rel=\"stylesheet\" href=\"css/materialize.min.css\"  media=\"screen,projection\"/>\n"
                            + "        <meta charset=\"UTF-8\">\n"
                            + "        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    </head>\n"
                            + "    <body style=\"background-image: url(IMG/mini.jpg) \">\n"
                            + "        <!--Import jQuery before materialize.js-->\n"
                            + "        <script type=\"text/javascript\" src=\"https://code.jquery.com/jquery-2.1.1.min.js\"></script>\n"
                            + "        <script type=\"text/javascript\" src=\"js/materialize.min.js\"></script> \n"
                            + "        <form action=\"nidas/cambios.jsp\" method=\"POST\" name=\"altas\">\n"
                            + "\n"
                            + "\n"
                            + "            <!--ÉSTA ES LA PARTE ROSA!!!-->\n"
                            + "            <nav>\n"
                            + "                <div class=\"nav-wrapper\" style=\"font-family: Raleway\">\n"
                            + "                    <!--a href=\"\" class=\"brand-logo\">Slogan de Armavi Fiore</a!-->\n"
                            + "                    <a href=\"\" class=\"brand-logo\" style=\"font-family: Shadows Into Light Two\">&nbsp;&nbsp; Consultale Papu</a>\n"
                            + "                    <ul id=\"nav-mobile\" class=\"right hide-on-med-and-down\">\n"
                            + "                        <li><a class=\"dropdown-button\" href=\" \" data-activates=\"quienessomos\">¿Quiénes somos?<i class=\"material-icons right\">arrow_drop_down</i></a></li>\n"
                            + "                        <li><a href=\"contacto.html\">Contacto</a></li>\n"
             
                            
                            + "                    </ul>\n"
                            + "\n"
                            + "                    <ul id=\"quienessomos\" class=\"dropdown-content\">\n"
                            + "                        <li><a href=\"sobreempresa.html\">Sobre la empresa</a></li>\n"
                            + "                        <li><a href=\"ubicacion.html\">Ubicación</a></li>\n"
                            + "                        <li><a href=\"nproductos.html\">Nuestros productos</a></li>\n"
                            + "                    </ul>\n"
                            + "                </div>\n"
                            + "            </nav>\n"
                            + "\n"
                            + "            <div class=\"row\">\n"
                            + "                <div class=\"col s3\"> </div>\n"
                            + "\n"
                            + "                <!-- Contenedor :3 -->\n"
                            + "                <div class=\"col s6\">\n"
                            + "                    <div class=\"container\" style=\"font-family: Raleway; font-size: 20px; \">\n"
                            + "                        <br><br>\n"
                            + "                        <!--h3 style=\"color: #050f14; font-family: Muli\">Regístrate!</h3-->\n"
                            + "\n");
                        out.println("<tr>"
                                + "<td>" + tipo + "</td>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + edad + "</td>"
                                + "<td>" + direccion + "</td>"
                                + "<td>" + correo + "</td>"
                                + "</tr>");
                               out.println( "                        </div> <!--del contenedor-->\n"
                            + "                    </div>\n"
                            + "                </div>\n"
                            + "                <div class=\"col s3\"> </div>\n"
                            + "\n"
                            + "            </div>\n"
                            + "        </form>\n"
                            + "    </body>\n"
                            + "</html>\n"
                            + "");
                        out.println();
                    }
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
        }
    }
}
