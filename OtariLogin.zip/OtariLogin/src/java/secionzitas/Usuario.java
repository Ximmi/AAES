package secionzitas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alumno
 */
public class Usuario {

    private String nombre;
    private String contra;
    private int edad;
    private String correo;
    private String direccion;
    private int idU;

    public Usuario() {
    }

    public Usuario(String nombre, String contra, int edad, String correo, String direccion, int idU) {

        this.nombre = nombre;
        this.contra = contra;
        this.edad = edad;
        this.correo = correo;
        this.direccion = direccion;
        this.idU = idU;

    }

    public int getIdU() {
        return idU;
    }

    public void setIdU(int idU) {
        this.idU = idU;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

}
