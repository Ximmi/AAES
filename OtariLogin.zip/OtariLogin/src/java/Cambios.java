/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;

/**
 *
 * @author Alumno
 */
public class Cambios extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            String nombre = request.getParameter("nombre");

            Connection c = null;
            Statement s = null;
            ResultSet r = null;

            try {
                BD.cDatos cambio = new BD.cDatos();
                cambio.conectar();

                r = cambio.consulta("select *from Usuario where nombre='" + nombre + "'");
                out.print("<table border='1'>");
                
                out.println("<script>"
                        + "function Mostrar(tipo, nombre, edad, direccion, correo){"
                        + ""
                        + "}"
                        + "</script>");
                
                if (r.next()) {
                    String tipo = r.getString("tipo");
                    String edad = r.getString("edad");
                    String direccion = r.getString("direccion");
                    String correo = r.getString("correo");

                    out.println("<tr>"
                            + "<td>" + tipo + "</td>"
                            + "<td>" + nombre + "</td>"
                            + "<td>" + edad + "</td>"
                            + "<td>" + direccion + "</td>"
                            + "</tr>");
                    out.println("<input type='button' name='Cambio' value='cambio' onclick='Mostrar(tipo, nombre, edad, direccion, correo)'/>");
                } else {
                    out.println("<script>alert('Usuario inexistente')</script>");
                    response.sendRedirect(".../cambios.html");
                }
                out.println("<script>alert('Cambios realizados correctamente');</script>");
                cambio.cierraConexion();

            } catch (SQLException error) {
                out.print(error.toString());
            }
        }
    }
}
