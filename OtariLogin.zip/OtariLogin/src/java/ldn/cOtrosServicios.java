/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ldn;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author CECyT9
 */
public class cOtrosServicios {
      String _error = "";

    public String AgregarOS(String nombre, int precio, String decoracion) throws SQLException {
        BD.cDatos sql = new BD.cDatos();
        String resp = "";
        ResultSet con = null;
        try {
            sql.conectar();

            con = sql.consulta("call AgregarOtrosServicios('" + nombre + "','" + precio + "', '" + decoracion + "');");

            sql.cierraConexion();

        } catch (Exception e) {
            resp = e.getMessage();
        }

        return resp;

    }
}
