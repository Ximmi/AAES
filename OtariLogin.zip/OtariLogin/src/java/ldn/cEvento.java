/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ldn;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.lang.IllegalArgumentException;
/**
 *
 * @author Usuario
 */
public class cEvento {
       String _error = "";
       
       public String AgregarEvent(String nombre,String lugar, String tipo, String invitados, String fechaEvento, String Hora) throws SQLException{
        BD.cDatos base = new BD.cDatos();
        String resp = "";
        ResultSet con = null;
        try {
            base.conectar();
        con = base.consulta("call AgregarEvento('"+nombre+"','"+lugar+"','"+tipo+"','"+invitados+"', '"+fechaEvento+"','"+Hora+"');" );
        base.cierraConexion();
            
        } catch (Exception e) {
            resp = e.getMessage();
        }
       
        
        return resp;
        
        
    }
       
}
