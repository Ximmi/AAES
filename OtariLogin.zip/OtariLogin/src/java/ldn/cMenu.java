/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ldn;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author Diego y Ximmi (5-12-16)
 */
public class cMenu {
    String _error = "";
       
       public String AgregarMenu(String entrada, String aperitivo, String principal, String postre, String bebidas) throws SQLException{
        BD.cDatos base = new BD.cDatos();
        String resp = "";
        ResultSet con = null;
        try {
            base.conectar();
        con = base.consulta("call AgregarMenu('"+entrada+"','"+aperitivo+"','"+principal+"', '"+postre+"','"+bebidas+"');" );
        base.cierraConexion();
            
        } catch (Exception e) {
            resp = e.getMessage();
        }
       
        
        return resp;
        
        
    }
}
