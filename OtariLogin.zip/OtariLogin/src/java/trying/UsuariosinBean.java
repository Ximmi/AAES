
package trying;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import trying.Usuario;
/**
 *
 * @author Alumno
 * Modificado por Ximmi 2/12/16
 */
public class UsuariosinBean {
     public static boolean agregarUsuario(Usuario usuario){
  boolean agregado=false;
  try {
   Conexion c=new Conexion();
   Connection con=c.getConexion();
   if(con!=null){
    Statement st;
    st = con.createStatement();
    st.executeUpdate("INSERT INTO Usuario('tipo','nombre','edad', 'direccion','contra','correo') VALUES ('"+usuario.getTipo()+"','"+usuario.getNombre()+"','"+usuario.getEdad()+"','"+usuario.getDireccion()+"','"+usuario.getContra()+"','"+usuario.getCorreo()+"')");
    agregado=true;
    st.close();
   }
   c.cerrarConexion();
  } catch (SQLException e) {
   agregado=false;
   e.printStackTrace();
  }
  return agregado;
 }
}

