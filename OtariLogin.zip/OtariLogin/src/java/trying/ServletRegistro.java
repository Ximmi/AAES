/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trying;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import trying.Usuario;
import trying.UsuariosinBean;
/**
 *
 * @author Alumno
 * Modificado por Ximmi (2/12/16)
 */
public class ServletRegistro extends HttpServlet{
    private static final long serialVersionUID = 1L;
    public ServletRegistro() {
    }
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  String nombre=request.getParameter("nombre");
  String edad=request.getParameter("edad");
  String direccion=request.getParameter("direccion");
  String correo=request.getParameter("correo");
  String contra=request.getParameter("contra");
  String tipo=request.getParameter("tipo");
  if(!nombre.equalsIgnoreCase("") && !correo.equalsIgnoreCase("") && !edad.equalsIgnoreCase("") && !direccion.equalsIgnoreCase("") && !contra.equalsIgnoreCase("") && !tipo.equalsIgnoreCase("")){
   Usuario busuario=new Usuario(nombre, contra, edad, correo, direccion, tipo);
   boolean sw=UsuariosinBean.agregarUsuario(busuario);
   if(sw){
    request.getRequestDispatcher("Mensaje.jsp").forward(request, response);
   }else{
    PrintWriter out=response.getWriter();
    out.println("<script>alert('Algo salió muuy mal')</script>");
   }
  }
 }
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  String nombre=request.getParameter("nombre");
  String direccion=request.getParameter("direccion");
  String edad=request.getParameter("edad");
  String correo=request.getParameter("correo");
  String contra=request.getParameter("contra");
  String tipo=request.getParameter("tipo");
  if(!nombre.equalsIgnoreCase("") && !correo.equalsIgnoreCase("") && !edad.equalsIgnoreCase("") && !direccion.equalsIgnoreCase("") && !contra.equalsIgnoreCase("") && !tipo.equalsIgnoreCase("")){
   Usuario busuario=new Usuario(nombre, contra, edad, correo, direccion, tipo);
   boolean sw=UsuariosinBean.agregarUsuario(busuario);
   if(sw){
    request.getRequestDispatcher("Mensaje.jsp").forward(request, response);
   }else{
    PrintWriter out=response.getWriter();
    out.println("<script>alert('Algo salió muuy mal')</script>");
   }
  }
 }
}
