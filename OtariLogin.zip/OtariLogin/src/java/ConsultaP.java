/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author EdgarAntonio
 */
public class ConsultaP extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            String submit = request.getParameter("submit");
            String nom = request.getParameter("nombre");
            String cos = request.getParameter("costo");

            float costos;
            costos = Float.parseFloat(cos);

            Connection c = null;
            Statement s = null;
            ResultSet r = null;

            if (submit.equals("Consulta nombre")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Decoracion where nombre='" + nom + "'");
                    out.println("<table border='1'");

                    if (r.next()) {
                        String nombre = r.getString("nombre");
                        float costo = r.getFloat("costo");

                        out.println("<tr>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + costo + "</td>"
                                + "</tr>");
                    }
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
            if (submit.equals("Consultar todo")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Decoracion");
                    out.println("<table border='1'");

                    while (r.next()) {
                        String nombre = r.getString("nombre");
                        float costo = r.getFloat("costo");

                        out.println("<tr>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + costo + "</td>"
                                + "</tr>");
                    }
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
            if (submit.equals("Mayor que")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Decoracion");
                    out.println("<table border='1'");

                    if(r.next()) {
                        String nombre = r.getString("nombre");
                        float costo = r.getFloat("costo");
                        
                        while(costos>=costo){
                        out.println("<tr>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + costo + "</td>"
                                + "</tr>");
                        }
                    }
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
            if (submit.equals("Menor que")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Decoracion");
                    out.println("<table border='1'");

                    if(r.next()) {
                        String nombre = r.getString("nombre");
                        float costo = r.getFloat("costo");
                        
                        while(costos<=costo){
                        out.println("<tr>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + costo + "</td>"
                                + "</tr>");
                        }
                    }
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
            if (submit.equals("Igual que")) {
                try {
                    BD.cDatos conec = new BD.cDatos();
                    conec.conectar();
                    r = conec.consulta("select * from Decoracion where costo='" + costos + "'");
                    out.println("<table border='1'");

                    if (r.next()) {
                        String nombre = r.getString("nombre");
                        float costo = r.getFloat("costo");

                        out.println("<tr>"
                                + "<td>" + nombre + "</td>"
                                + "<td>" + costo + "</td>"
                                + "</tr>");
                    }
                } catch (SQLException ex) {
                    ex.toString();
                }
            }
        }
    }
}
